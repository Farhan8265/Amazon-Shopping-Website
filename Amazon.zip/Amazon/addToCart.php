<?php
session_start();

// Function to add a product to the cart
function addToCart($productName) {
    // Initialize cart session variable if not set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Add the product to the cart
    if (isset($_SESSION['cart'][$productName])) {
        $_SESSION['cart'][$productName]++;
    } else {
        $_SESSION['cart'][$productName] = 1;
    }

    // Calculate total cart count
    $totalCartCount = array_sum($_SESSION['cart']);

    // Return the total cart count
    echo $totalCartCount;
}

// Get the product name from the POST request
$productName = isset($_POST['productName']) ? $_POST['productName'] : '';

// Call the addToCart function
addToCart($productName);
?>
